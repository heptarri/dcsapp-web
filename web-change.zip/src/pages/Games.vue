<template>
  <div>
    <categoryComponent category="Games"></categoryComponent>
  </div>
</template>

<script>
import categoryComponent from "../components/categoryComponent.vue";

export default {
  name: "Games",
  components: {
    categoryComponent
  },
  data() {
    return {
    };
  },
  methods: {
  },
  mounted() {
  }
};
</script>


<style scoped>
</style>
